#include<stdio.h>
#include<stdlib.h>
#include<string.h> 
#include<time.h>
#include<windows.h>

#include"Hospital.h"
#include"main.h" 
#include"func1.h"
#include"func2.h"
#include"func3.h"
#include"func4.h"
#include"func5.h"
#include"func6.h"
#include"option.h"
#include"option1.h"

int main()
{
	records->next=NULL;
	records->before=NULL;
	pointer=records;
	option1(); 
	return 0;
}
