#ifndef FUNC6_H_INCLUDED
#define FUNC6_H_INCLUDED

void func6()
{
	func5();
	exit(0);
} 
#endif
