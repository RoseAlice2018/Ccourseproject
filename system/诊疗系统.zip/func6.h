
void func6()
{
	exit(0);
} 
