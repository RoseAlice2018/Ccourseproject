#include<stdio.h>
#include<stdlib.h>
#include<string.h> 
#include<time.h>
#include<windows.h>

#include"Hospital.h"
#include"main.h" 
#include"func1.h"
#include"func4.h"
#include"func6.h"
#include"option.h"

int main()
{
	option(); 
	return 0;
}
